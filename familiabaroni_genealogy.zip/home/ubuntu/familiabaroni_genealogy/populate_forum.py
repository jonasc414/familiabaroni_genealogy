from src.main import app, db
from src.models.forum import ForumCategory

def populate_forum_categories():
    with app.app_context():
        # Categorias por localização
        locations = [
            {
                'name': 'São Paulo',
                'description': 'Discussões sobre a família Baroni em São Paulo',
                'category_type': 'location',
                'icon': 'fas fa-map-marker-alt',
                'color': '#28a745'
            },
            {
                'name': 'Veneto, Itália',
                'description': 'Origens da família na região do Veneto',
                'category_type': 'location',
                'icon': 'fas fa-globe-europe',
                'color': '#dc3545'
            },
            {
                'name': 'Outras Localidades',
                'description': 'Família Baroni em outras cidades e países',
                'category_type': 'location',
                'icon': 'fas fa-map',
                'color': '#6f42c1'
            }
        ]
        
        # Categorias por sobrenome
        surnames = [
            {
                'name': 'Linhagem Baroni',
                'description': 'Discussões sobre a linhagem principal dos Baroni',
                'category_type': 'surname',
                'icon': 'fas fa-users',
                'color': '#007bff'
            },
            {
                'name': 'Famílias Relacionadas',
                'description': 'Rossi, Silva, Santos e outras famílias relacionadas',
                'category_type': 'surname',
                'icon': 'fas fa-sitemap',
                'color': '#fd7e14'
            }
        ]
        
        # Categorias por descendência
        ancestry = [
            {
                'name': 'Giuseppe Baroni',
                'description': 'Descendentes do patriarca Giuseppe Baroni',
                'category_type': 'ancestry',
                'icon': 'fas fa-crown',
                'color': '#ffc107'
            },
            {
                'name': 'Antonio Baroni',
                'description': 'Descendentes de Antonio Baroni',
                'category_type': 'ancestry',
                'icon': 'fas fa-tree',
                'color': '#20c997'
            },
            {
                'name': 'Carlos Baroni',
                'description': 'Descendentes de Carlos Baroni',
                'category_type': 'ancestry',
                'icon': 'fas fa-seedling',
                'color': '#17a2b8'
            }
        ]
        
        # Categorias gerais
        general = [
            {
                'name': 'Geral',
                'description': 'Discussões gerais sobre a família',
                'category_type': 'general',
                'icon': 'fas fa-comments',
                'color': '#6c757d'
            },
            {
                'name': 'Eventos Familiares',
                'description': 'Reuniões, casamentos, aniversários e outros eventos',
                'category_type': 'general',
                'icon': 'fas fa-calendar-alt',
                'color': '#e83e8c'
            },
            {
                'name': 'Pesquisa Genealógica',
                'description': 'Ajuda e dicas para pesquisa genealógica',
                'category_type': 'general',
                'icon': 'fas fa-search',
                'color': '#6f42c1'
            }
        ]
        
        all_categories = locations + surnames + ancestry + general
        
        for cat_data in all_categories:
            # Verifica se a categoria já existe
            existing = ForumCategory.query.filter_by(name=cat_data['name']).first()
            if not existing:
                category = ForumCategory(**cat_data)
                db.session.add(category)
        
        db.session.commit()
        print("Categorias do fórum criadas com sucesso!")

if __name__ == '__main__':
    populate_forum_categories()

