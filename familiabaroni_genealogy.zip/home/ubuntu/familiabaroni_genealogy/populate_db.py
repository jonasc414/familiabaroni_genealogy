from src.main import app, db
from src.models.person import Person
from src.models.family_tree import FamilyTree

def populate_baroni_family():
    with app.app_context():
        # Criar árvore genealógica da família Baroni
        baroni_tree = FamilyTree(
            name="Família Baroni",
            description="Árvore genealógica da família Baroni"
        )
        db.session.add(baroni_tree)
        
        # Criar algumas pessoas da família Baroni (exemplo)
        # Trisavô fundador
        giuseppe_baroni = Person(
            name="Giuseppe Baroni",
            birth_date="1850-01-15",
            birth_place="Veneto, Itália",
            death_date="1920-12-10",
            death_place="São Paulo, Brasil",
            gender="M",
            notes="Patriarca da família Baroni no Brasil, imigrou da Itália em 1880"
        )
        db.session.add(giuseppe_baroni)
        
        maria_rossi = Person(
            name="Maria Rossi Baroni",
            birth_date="1855-03-20",
            birth_place="Veneto, Itália",
            death_date="1925-08-15",
            death_place="São Paulo, Brasil",
            gender="F",
            notes="Esposa de Giuseppe Baroni"
        )
        db.session.add(maria_rossi)
        
        # Bisavô
        antonio_baroni = Person(
            name="Antonio Baroni",
            birth_date="1880-05-10",
            birth_place="São Paulo, Brasil",
            death_date="1950-11-20",
            death_place="São Paulo, Brasil",
            gender="M",
            notes="Filho de Giuseppe e Maria, expandiu os negócios da família"
        )
        db.session.add(antonio_baroni)
        
        lucia_silva = Person(
            name="Lucia Silva Baroni",
            birth_date="1885-07-25",
            birth_place="São Paulo, Brasil",
            death_date="1955-04-30",
            death_place="São Paulo, Brasil",
            gender="F",
            notes="Esposa de Antonio Baroni"
        )
        db.session.add(lucia_silva)
        
        # Avô
        carlos_baroni = Person(
            name="Carlos Baroni",
            birth_date="1910-02-14",
            birth_place="São Paulo, Brasil",
            death_date="1980-09-05",
            death_place="São Paulo, Brasil",
            gender="M",
            notes="Filho de Antonio e Lucia"
        )
        db.session.add(carlos_baroni)
        
        ana_santos = Person(
            name="Ana Santos Baroni",
            birth_date="1915-06-18",
            birth_place="São Paulo, Brasil",
            death_date="1985-12-22",
            death_place="São Paulo, Brasil",
            gender="F",
            notes="Esposa de Carlos Baroni"
        )
        db.session.add(ana_santos)
        
        # Pai
        roberto_baroni = Person(
            name="Roberto Baroni",
            birth_date="1940-08-30",
            birth_place="São Paulo, Brasil",
            gender="M",
            notes="Filho de Carlos e Ana"
        )
        db.session.add(roberto_baroni)
        
        # Commit para obter IDs
        db.session.commit()
        
        # Estabelecer relacionamentos familiares
        antonio_baroni.father_id = giuseppe_baroni.id
        antonio_baroni.mother_id = maria_rossi.id
        
        carlos_baroni.father_id = antonio_baroni.id
        carlos_baroni.mother_id = lucia_silva.id
        
        roberto_baroni.father_id = carlos_baroni.id
        roberto_baroni.mother_id = ana_santos.id
        
        # Definir pessoa raiz da árvore
        baroni_tree.root_person_id = giuseppe_baroni.id
        
        db.session.commit()
        print("Banco de dados populado com sucesso com a família Baroni!")

if __name__ == '__main__':
    populate_baroni_family()

