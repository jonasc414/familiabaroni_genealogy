# Site Família Baroni - Árvore Genealógica

Um site completo para pesquisa e conexão da árvore genealógica da família Baroni, com funcionalidades de rede social, galeria de fotos, fórum e livro de visitas.

## 🌟 Funcionalidades

### 👥 Sistema de Usuários
- **Registro completo**: Nome, e-mail, data de nascimento, informações dos pais e avós
- **Autenticação social**: Suporte para login com Facebook (configuração necessária)
- **Perfis de usuário**: Páginas personalizadas para cada membro da família

### 🌳 Árvore Genealógica
- **Base de dados pré-populada** com a família Baroni
- **Visualização interativa** das relações familiares
- **Busca e filtros** por nome, geração e relacionamento
- **Indicadores estatísticos**: Pessoas cadastradas, gerações, etc.

### 🤝 Rede Social Interna
- **Conexões entre parentes**: Sistema de amizade familiar
- **Posts e interações**: Compartilhamento de memórias e novidades
- **Perfis detalhados**: Informações e conexões de cada membro

### 📸 Galeria e Álbuns
- **Upload de fotos**: Direto do celular ou computador
- **Upload de documentos**: PDFs, DOCs para preservar história familiar
- **Organização em álbuns**: Categorização por eventos, pessoas, etc.
- **Associação a pessoas**: Vincular fotos a membros específicos da família
- **Tags e descrições**: Sistema de busca e organização

### 💬 Fórum Organizado
Categorias especializadas conforme solicitado:

#### Por Localização
- **São Paulo**: Discussões sobre a família em SP
- **Veneto, Itália**: Origens da família na Itália
- **Outras Localidades**: Família em outras cidades/países

#### Por Sobrenome
- **Linhagem Baroni**: Discussões sobre a linhagem principal
- **Famílias Relacionadas**: Rossi, Silva, Santos e outras

#### Por Descendência
- **Giuseppe Baroni**: Descendentes do patriarca
- **Antonio Baroni**: Ramo de Antonio
- **Carlos Baroni**: Ramo de Carlos

#### Categorias Gerais
- **Discussões Gerais**: Tópicos diversos da família
- **Eventos Familiares**: Reuniões, casamentos, aniversários
- **Pesquisa Genealógica**: Dicas e ajuda para pesquisa

### 📖 Livro de Visitas
- **Mensagens públicas**: Visitantes podem deixar mensagens
- **Suporte a anônimos**: Não é necessário estar logado
- **Moderação**: Sistema de aprovação de mensagens

## 🚀 Instalação e Configuração

### Pré-requisitos
- Python 3.11+
- pip (gerenciador de pacotes Python)

### Instalação

1. **Clone ou baixe o projeto**
```bash
cd familiabaroni_genealogy
```

2. **Crie e ative o ambiente virtual**
```bash
python -m venv venv

# No Windows:
venv\\Scripts\\activate

# No Linux/Mac:
source venv/bin/activate
```

3. **Instale as dependências**
```bash
pip install flask flask-cors flask-login
```

4. **Inicialize o banco de dados**
```bash
python init_db.py
python populate_db.py
python populate_forum.py
```

5. **Execute o servidor**
```bash
python test_server.py
```

6. **Acesse o site**
Abra seu navegador e vá para: `http://localhost:5001`

## 📁 Estrutura do Projeto

```
familiabaroni_genealogy/
├── src/
│   ├── main.py                 # Aplicação principal Flask
│   ├── database.py             # Configuração do banco de dados
│   ├── models/                 # Modelos de dados
│   │   ├── user.py            # Modelo de usuário
│   │   ├── person.py          # Modelo de pessoa (árvore)
│   │   ├── family_tree.py     # Relacionamentos familiares
│   │   ├── social.py          # Rede social
│   │   ├── media.py           # Arquivos e álbuns
│   │   └── forum.py           # Fórum e livro de visitas
│   ├── routes/                 # Rotas da API
│   │   ├── user.py            # Autenticação e usuários
│   │   ├── genealogy.py       # Árvore genealógica
│   │   ├── social.py          # Rede social
│   │   ├── media.py           # Upload e galeria
│   │   └── forum.py           # Fórum e livro de visitas
│   └── static/                 # Frontend
│       ├── index.html         # Página principal
│       ├── style.css          # Estilos
│       └── app.js             # JavaScript
├── venv/                       # Ambiente virtual Python
├── init_db.py                  # Script de inicialização do BD
├── populate_db.py              # Dados iniciais da família
├── populate_forum.py           # Categorias do fórum
├── test_server.py              # Servidor de desenvolvimento
└── README.md                   # Esta documentação
```

## 🔧 Configuração para Produção

### Hospedagem
Para hospedar em um subdiretório do seu site principal:

1. **Configure o servidor web** (Apache/Nginx) para servir os arquivos estáticos
2. **Configure o WSGI** para executar a aplicação Flask
3. **Ajuste as URLs** se necessário para o subdiretório
4. **Configure HTTPS** para segurança

### Autenticação Social (Facebook)
Para ativar o login com Facebook:

1. Crie uma aplicação no Facebook Developers
2. Configure as URLs de callback
3. Adicione as credenciais no arquivo de configuração
4. Instale a biblioteca: `pip install flask-dance`

### Banco de Dados
Para produção, considere migrar para PostgreSQL ou MySQL:

1. Instale o driver apropriado
2. Atualize a string de conexão em `src/main.py`
3. Execute as migrações necessárias

## 📱 Recursos Mobile

O site é totalmente responsivo e otimizado para dispositivos móveis:
- **Upload de fotos** direto da câmera do celular
- **Interface touch-friendly**
- **Navegação adaptativa**
- **Formulários otimizados** para telas pequenas

## 🔒 Segurança

- **Autenticação segura** com hash de senhas
- **Validação de uploads** com tipos de arquivo permitidos
- **Proteção CSRF** implementada
- **Sanitização de dados** de entrada

## 🎨 Personalização

### Cores e Tema
Edite o arquivo `src/static/style.css` para personalizar:
- Cores da família
- Logotipo
- Fontes
- Layout

### Dados da Família
Edite o arquivo `populate_db.py` para:
- Adicionar mais membros da família
- Atualizar informações existentes
- Incluir novas gerações

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique os logs do servidor
2. Confirme se todas as dependências estão instaladas
3. Teste em modo de desenvolvimento primeiro

## 📄 Licença

Este projeto foi desenvolvido especificamente para a família Baroni. Todos os direitos reservados.

---

**Desenvolvido com ❤️ para preservar e conectar a história da família Baroni**

