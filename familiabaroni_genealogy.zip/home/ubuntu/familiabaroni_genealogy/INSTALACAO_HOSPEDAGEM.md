# Instruções para Hospedagem no www.familiabaroni.com.br

## 📋 Preparação para Upload

### 1. Estrutura de Arquivos para Upload
Faça upload dos seguintes arquivos para um subdiretório do seu site (ex: `/genealogia/`):

```
genealogia/
├── src/
│   ├── main.py
│   ├── database.py
│   ├── models/
│   ├── routes/
│   └── static/
├── venv/ (criar no servidor)
├── *.py (scripts de inicialização)
└── requirements.txt
```

### 2. Arquivo requirements.txt
Crie um arquivo `requirements.txt` com as dependências:
```
Flask==2.3.3
Flask-CORS==4.0.0
Flask-Login==0.6.3
Flask-SQLAlchemy==3.0.5
```

## 🔧 Configuração no Servidor

### 1. Ambiente Python
```bash
# No servidor, navegue até o diretório
cd /caminho/para/genealogia

# Crie o ambiente virtual
python3 -m venv venv
source venv/bin/activate

# Instale as dependências
pip install -r requirements.txt
```

### 2. Inicialização do Banco de Dados
```bash
# Execute os scripts de inicialização
python init_db.py
python populate_db.py
python populate_forum.py
```

### 3. Configuração do Apache/Nginx

#### Para Apache (.htaccess)
Crie um arquivo `.htaccess` no diretório:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ wsgi.py/$1 [QSA,L]
```

#### Arquivo WSGI (wsgi.py)
```python
#!/usr/bin/python3
import sys
import os

# Adicione o caminho do projeto
sys.path.insert(0, "/caminho/para/genealogia/")

# Ative o ambiente virtual
activate_this = '/caminho/para/genealogia/venv/bin/activate_this.py'
exec(open(activate_this).read(), dict(__file__=activate_this))

from src.main import app as application

if __name__ == "__main__":
    application.run()
```

### 4. Configuração de Permissões
```bash
# Defina permissões adequadas
chmod 755 genealogia/
chmod 644 genealogia/src/static/*
chmod 755 genealogia/src/static/uploads/
```

## 🌐 Configuração de URL

### 1. Ajuste de Caminhos
Se hospedado em subdiretório, ajuste em `src/main.py`:
```python
# Adicione o prefixo do subdiretório
app = Flask(__name__, static_url_path='/genealogia/static')
```

### 2. URLs de Acesso
- **Site principal**: `https://www.familiabaroni.com.br/genealogia/`
- **API**: `https://www.familiabaroni.com.br/genealogia/api/`

## 🔒 Configurações de Segurança

### 1. Variáveis de Ambiente
Crie um arquivo `.env` (não incluir no controle de versão):
```
SECRET_KEY=sua_chave_secreta_muito_forte_aqui
DATABASE_URL=sqlite:///genealogia.db
UPLOAD_FOLDER=/caminho/completo/para/uploads
```

### 2. Configuração SSL
Certifique-se de que o site principal já tem SSL configurado.

### 3. Backup do Banco de Dados
Configure backup automático do arquivo `genealogia.db`:
```bash
# Exemplo de script de backup
#!/bin/bash
cp /caminho/para/genealogia/src/database/app.db /backup/genealogia_$(date +%Y%m%d).db
```

## 📱 Teste da Instalação

### 1. Verificações Básicas
- [ ] Site carrega em `https://www.familiabaroni.com.br/genealogia/`
- [ ] Formulário de registro funciona
- [ ] Árvore genealógica carrega
- [ ] Fórum exibe categorias
- [ ] Livro de visitas aceita mensagens
- [ ] Upload de arquivos funciona

### 2. Teste Mobile
- [ ] Site responsivo em dispositivos móveis
- [ ] Upload de fotos do celular funciona
- [ ] Navegação touch-friendly

## 🚨 Solução de Problemas

### Erro 500 - Internal Server Error
1. Verifique os logs do servidor
2. Confirme permissões dos arquivos
3. Verifique se o ambiente virtual está ativo
4. Confirme se todas as dependências estão instaladas

### Problemas de Upload
1. Verifique permissões da pasta `uploads/`
2. Confirme limite de upload do servidor
3. Verifique espaço em disco disponível

### Banco de Dados não Carrega
1. Verifique se `init_db.py` foi executado
2. Confirme permissões do arquivo de banco
3. Verifique se o caminho está correto

## 📞 Contato para Suporte

Em caso de dificuldades na instalação:
1. Verifique os logs de erro do servidor
2. Teste primeiro em ambiente local
3. Confirme compatibilidade da versão Python do servidor

## 🔄 Atualizações Futuras

Para atualizar o site:
1. Faça backup do banco de dados
2. Substitua os arquivos de código
3. Execute migrações se necessário
4. Teste todas as funcionalidades

---

**Nota**: Este site foi desenvolvido especificamente para a família Baroni e contém dados genealógicos pré-populados. Personalize conforme necessário antes da instalação.

